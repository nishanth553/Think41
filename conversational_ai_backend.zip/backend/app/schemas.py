
from pydantic import BaseModel
from typing import List
from datetime import datetime

class MessageCreate(BaseModel):
    role: str
    content: str

class MessageOut(BaseModel):
    role: str
    content: str
    timestamp: datetime
    class Config:
        orm_mode = True

class SessionOut(BaseModel):
    id: int
    created_at: datetime
    messages: List[MessageOut] = []
    class Config:
        orm_mode = True

class UserCreate(BaseModel):
    username: str

class UserOut(BaseModel):
    id: int
    username: str
    class Config:
        orm_mode = True
