
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from . import models, schemas, crud
from .database import Base, engine, SessionLocal
import os, requests

from dotenv import load_dotenv
load_dotenv()

Base.metadata.create_all(bind=engine)
app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/users/", response_model=schemas.UserOut)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    return crud.create_user(db, user.username)

@app.post("/sessions/{user_id}/", response_model=schemas.SessionOut)
def create_chat_session(user_id: int, db: Session = Depends(get_db)):
    return crud.create_session(db, user_id)

@app.post("/messages/{session_id}/")
def add_message(session_id: int, message: schemas.MessageCreate, db: Session = Depends(get_db)):
    return crud.add_message(db, session_id, message.role, message.content)

@app.get("/sessions/{session_id}/", response_model=schemas.SessionOut)
def get_messages(session_id: int, db: Session = Depends(get_db)):
    messages = crud.get_session_messages(db, session_id)
    return {"id": session_id, "created_at": messages[0].timestamp if messages else None, "messages": messages}

@app.post("/api/chat/")
def chat(username: str, message: str, session_id: int = None, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == username).first()
    if not user:
        user = crud.create_user(db, username)

    if session_id is None:
        session = crud.create_session(db, user.id)
        session_id = session.id
    else:
        session = db.query(models.Session).filter(models.Session.id == session_id).first()
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

    crud.add_message(db, session_id, role="user", content=message)
    llm_response = call_groq_llm(message)
    crud.add_message(db, session_id, role="assistant", content=llm_response)

    return {
        "session_id": session_id,
        "user_message": message,
        "ai_response": llm_response
    }

def call_groq_llm(prompt: str):
    headers = {
        "Authorization": f"Bearer {os.getenv('GROQ_API_KEY')}",
        "Content-Type": "application/json"
    }
    data = {
        "messages": [
            {"role": "system", "content": "You're an AI assistant for an e-commerce site. Ask clarifying questions when needed."},
            {"role": "user", "content": prompt}
        ],
        "model": "mixtral-8x7b-32768"
    }
    response = requests.post("https://api.groq.com/openai/v1/chat/completions", json=data, headers=headers)
    if response.status_code != 200:
        return "Sorry, I couldn't respond due to an internal error."
    return response.json()['choices'][0]['message']['content']
