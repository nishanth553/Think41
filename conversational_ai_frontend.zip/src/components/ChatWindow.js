
import React from 'react';
import MessageList from './MessageList';
import UserInput from './UserInput';
import ConversationHistory from './ConversationHistory';
import './ChatWindow.css';

const ChatWindow = () => {
  return (
    <div className="chat-window">
      <ConversationHistory />
      <div className="chat-area">
        <MessageList />
        <UserInput />
      </div>
    </div>
  );
};

export default ChatWindow;
