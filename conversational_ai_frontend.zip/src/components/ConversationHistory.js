
import React, { useContext } from 'react';
import { ChatContext } from '../context/ChatContext';

const ConversationHistory = () => {
  const { sessions, setMessages, setActiveSession } = useContext(ChatContext);

  const loadSession = session => {
    setMessages(session.messages);
    setActiveSession(session.id);
  };

  return (
    <div className="conversation-history">
      <h3>Past Sessions</h3>
      {sessions.map(session => (
        <div key={session.id} onClick={() => loadSession(session)}>
          Session {session.id}
        </div>
      ))}
    </div>
  );
};

export default ConversationHistory;
