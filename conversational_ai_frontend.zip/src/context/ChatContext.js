
import React, { createContext, useState } from 'react';

export const ChatContext = createContext();

export const ChatProvider = ({ children }) => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [sessions, setSessions] = useState([]);
  const [activeSession, setActiveSession] = useState(null);

  return (
    <ChatContext.Provider value={{
      messages,
      setMessages,
      loading,
      setLoading,
      inputValue,
      setInputValue,
      sessions,
      setSessions,
      activeSession,
      setActiveSession
    }}>
      {children}
    </ChatContext.Provider>
  );
};
